class Constants {
  static const String baseAssetPath = "assets/";
  static const String baseApiUrl = "";
  static const String dummyAvatar = "https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50?s=200";

  //test env
  static const String createOrderUrl = "https://api.razorpay.com/v1/orders";
  static const String keySecret = "E0rXQPk7O1V9nymCsWpGlNHt";
  static const String keyId = "rzp_test_18uZyRVD8VK3Wv";
}
